package com.blogspot.kartunama.kartu_nama

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
