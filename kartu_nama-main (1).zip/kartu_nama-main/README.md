# kartu_nama

## Latihan membuat aplikasi Android dengan Flutter

Proyek kartu nama ini merupakan kode dasar untuk membuat aplikasi kartu nama.

Untuk belajar Flutter silakan mengikuti tutorial di:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Build Native Mobile Apps with Flutter](https://www.udacity.com/course/build-native-mobile-apps-with-flutter--ud905)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)
- [Dokumentasi online](https://flutter.dev/docs)

Selebihnya panduan belajar bersama untuk berbagai tutorial tsb. lihat di [Belajar Flutter](https://github.com/sslaia/belajar_flutter)
